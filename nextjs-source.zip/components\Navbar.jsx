'use client';
import React, { useEffect, useState } from 'react';
import { Settings, LogOut, Radio, Zap } from 'lucide-react';
import { signInWithGoogle, logOut } from '../lib/firebase';

export default function Navbar({ user, onOpenSettings, showToast }) {
  const [displayHz, setDisplayHz] = useState(null);

  useEffect(() => {
    let frameCount = 0;
    let startTime = performance.now();
    const samples = [];
    let rafId = null;

    function measure(now) {
      frameCount++;
      const elapsed = now - startTime;
      if (elapsed >= 300) {
        const rawHz = Math.round((frameCount * 1000) / elapsed);
        samples.push(rawHz);

        if (samples.length >= 2) {
          const avgHz = Math.round(samples.reduce((a, b) => a + b, 0) / samples.length);
          let detected = avgHz;
          if (avgHz >= 110 && avgHz <= 130) detected = 120;
          else if (avgHz >= 135 && avgHz <= 155) detected = 144;
          else if (avgHz >= 158 && avgHz <= 175) detected = 165;
          else if (avgHz >= 230 && avgHz <= 250) detected = 240;
          else if (avgHz >= 55 && avgHz <= 65) detected = 60;
          else if (avgHz >= 70 && avgHz <= 80) detected = 75;

          setDisplayHz(detected);
          return;
        }

        frameCount = 0;
        startTime = performance.now();
      }
      rafId = requestAnimationFrame(measure);
    }

    rafId = requestAnimationFrame(measure);
    return () => {
      if (rafId) cancelAnimationFrame(rafId);
    };
  }, []);

  const handleLogin = async () => {
    try {
      showToast('Opening Google Sign-In...', 'info');
      await signInWithGoogle();
      showToast('Signed in successfully!', 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  const handleLogout = async () => {
    try {
      await logOut();
      showToast('Signed out', 'info');
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  return (
    <nav className="glass-panel rounded-3xl px-6 py-4 mb-8 flex items-center justify-between shadow-glass">
      {/* Brand */}
      <div className="flex items-center gap-3 cursor-pointer select-none">
        <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-white shadow-md border border-white/40">
          <Radio className="w-5 h-5 text-white" />
        </div>
        <div>
          <h1 className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-amber-900 via-amber-700 to-amber-600 bg-clip-text text-transparent">
            NovaStream
          </h1>
          <span className="text-[11px] font-extrabold uppercase tracking-wider text-amber-700">
            4K • 120Hz &amp; 60fps • Zero Latency
          </span>
        </div>
      </div>

      {/* Nav Actions */}
      <div className="flex items-center gap-3">
        {/* Real-time Display Hz Telemetry Pill */}
        {displayHz && (
          <div
            className={`hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-transform ${
              displayHz >= 100
                ? 'bg-emerald-50 text-emerald-800 border border-emerald-300 shadow-sm'
                : 'bg-amber-50 text-amber-800 border border-amber-200'
            }`}
            title={`Your display refresh rate is ${displayHz}Hz. NovaStream UI and stream engine are running with 120Hz native compositor alignment.`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                displayHz >= 100 ? 'bg-emerald-500 shadow-[0_0_8px_#10b981]' : 'bg-amber-500'
              }`}
            />
            <span className="flex items-center gap-0.5">
              <Zap className="w-3 h-3" />
              {displayHz}Hz Display
            </span>
          </div>
        )}

        {/* Network & TURN Settings Button */}
        <button
          onClick={onOpenSettings}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold text-amber-900 bg-white/60 hover:bg-white/90 border border-white/80 shadow-sm transition-transform active:scale-95"
          title="Network & TURN Relay Settings"
          type="button"
        >
          <Settings className="w-4 h-4 text-amber-700" />
          Settings
        </button>

        {/* Auth Button */}
        {user ? (
          <div className="flex items-center gap-2.5 bg-white/60 px-3 py-1 rounded-full border border-white/80 shadow-sm">
            <img
              src={user.photoURL || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(user.displayName || 'U')}`}
              alt={user.displayName || 'User'}
              className="w-7 h-7 rounded-full border border-amber-500 object-cover"
            />
            <span className="text-xs font-bold text-stone-800 max-w-[110px] truncate hidden md:inline">
              {user.displayName || 'User'}
            </span>
            <button
              onClick={handleLogout}
              className="text-stone-500 hover:text-rose-600 transition-colors p-1"
              title="Sign Out"
              type="button"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <button
            onClick={handleLogin}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold text-stone-800 bg-white/80 hover:bg-white border border-white/80 shadow-sm transition-all active:scale-95"
            type="button"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
            </svg>
            Sign In
          </button>
        )}
      </div>
    </nav>
  );
}

