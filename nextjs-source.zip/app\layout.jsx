import './globals.css';

export const metadata = {
  title: 'NovaStream — 4K & 1080p 120Hz/60FPS WebRTC Streaming',
  description: 'Ultra-low-latency peer-to-peer 120 FPS screen streaming with crystal clear audio and E2EE live chat.',
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="antialiased selection:bg-amber-500 selection:text-white">
        {children}
      </body>
    </html>
  );
}

