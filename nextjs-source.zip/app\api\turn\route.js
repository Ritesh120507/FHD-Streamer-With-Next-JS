import { NextResponse } from 'next/server';

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const appName = searchParams.get('appName') || process.env.METERED_APP_NAME || '';
  const apiKey = searchParams.get('apiKey') || process.env.METERED_API_KEY || '';

  if (!appName || !apiKey) {
    return NextResponse.json({ iceServers: [] });
  }

  const cleanApp = appName.trim().replace(/\.metered\.live$/, '').replace(/\.metered\.ca$/, '');
  const cleanKey = apiKey.trim();
  const url = `https://${cleanApp}.metered.live/api/v1/turn/credentials?apiKey=${cleanKey}`;

  try {
    const res = await fetch(url, { next: { revalidate: 1800 } });
    if (!res.ok) {
      return NextResponse.json({ error: `Metered API status ${res.status}` }, { status: res.status });
    }
    const iceServers = await res.json();
    return NextResponse.json({ iceServers: Array.isArray(iceServers) ? iceServers : [] });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

