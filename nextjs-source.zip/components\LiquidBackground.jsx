'use client';
import React from 'react';

export default function LiquidBackground() {
  return (
    <div className="liquid-bg-container">
      <div
        className="liquid-orb-item"
        style={{
          width: '580px',
          height: '580px',
          borderRadius: '46% 54% 62% 38% / 52% 44% 56% 48%',
          background: 'radial-gradient(circle, #fde047 0%, #f59e0b 70%)',
          top: '-12%',
          left: '-8%',
          animationDuration: '22s',
        }}
      />
      <div
        className="liquid-orb-item"
        style={{
          width: '620px',
          height: '620px',
          borderRadius: '58% 42% 48% 52% / 45% 58% 42% 55%',
          background: 'radial-gradient(circle, #fef08a 0%, #fbbf24 65%, #f59e0b 100%)',
          bottom: '-15%',
          right: '-10%',
          animationDuration: '26s',
        }}
      />
      <div
        className="liquid-orb-item"
        style={{
          width: '480px',
          height: '480px',
          borderRadius: '51% 49% 37% 63% / 60% 41% 59% 40%',
          background: 'radial-gradient(circle, #fed7aa 0%, #f59e0b 60%)',
          top: '35%',
          left: '45%',
          animationDuration: '18s',
          animationDelay: '-5s',
        }}
      />
      <div
        className="liquid-orb-item"
        style={{
          width: '380px',
          height: '380px',
          borderRadius: '64% 36% 55% 45% / 48% 62% 38% 52%',
          background: 'radial-gradient(circle, #fef9c3 0%, #facc15 75%)',
          bottom: '8%',
          left: '8%',
          animationDuration: '24s',
          animationDelay: '-9s',
        }}
      />
    </div>
  );
}

