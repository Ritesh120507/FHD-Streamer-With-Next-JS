'use client';
import React, { useState, useEffect } from 'react';
import { Video, Tv, Mic, Sparkles, CheckCircle2, Shield, ArrowRight, Loader2 } from 'lucide-react';
import { signInWithGoogle, logOut } from '../lib/firebase';
import { getAudioInputDevices } from '../lib/webrtc';

export default function LobbyView({
  user,
  onStartStream,
  onJoinStream,
  onOpenSettings,
  showToast,
  isStarting,
  isJoining,
  initialRoomCode = '',
}) {
  const [resolution, setResolution] = useState('1080p');
  const [frameRate, setFrameRate] = useState('120');
  const [bitrate, setBitrate] = useState('18');
  const [customRoomCode, setCustomRoomCode] = useState('');
  const [includeMic, setIncludeMic] = useState(false);
  const [micDevice, setMicDevice] = useState('');
  const [micDevices, setMicDevices] = useState([]);
  const [audioMode, setAudioMode] = useState('gaming');
  const [joinCode, setJoinCode] = useState(initialRoomCode);

  useEffect(() => {
    if (initialRoomCode) {
      setJoinCode(initialRoomCode.toUpperCase());
    }
  }, [initialRoomCode]);

  useEffect(() => {
    if (includeMic) {
      getAudioInputDevices().then((devices) => setMicDevices(devices));
    }
  }, [includeMic]);

  // Auto-tune recommended bitrate when resolution or frameRate changes
  useEffect(() => {
    const fps = parseInt(frameRate, 10) || 120;
    if (fps === 120) {
      if (resolution === '4k') setBitrate('50');
      else if (resolution === '1440p') setBitrate('25');
      else if (resolution === '1080p') setBitrate('18');
      else if (resolution === '720p') setBitrate('10');
    } else if (fps === 60) {
      if (resolution === '4k') setBitrate('25');
      else if (resolution === '1440p') setBitrate('18');
      else if (resolution === '1080p') setBitrate('10');
      else if (resolution === '720p') setBitrate('5');
    } else {
      if (resolution === '4k') setBitrate('18');
      else if (resolution === '1440p') setBitrate('12');
      else if (resolution === '1080p') setBitrate('8');
      else if (resolution === '720p') setBitrate('5');
    }
  }, [resolution, frameRate]);

  const handleStart = () => {
    if (!user) {
      showToast('Please sign in with Google first to start streaming.', 'warning');
      signInWithGoogle().catch((e) => showToast(e.message, 'error'));
      return;
    }

    onStartStream({
      resolution,
      frameRate: parseInt(frameRate, 10),
      bitrateMbps: parseInt(bitrate, 10),
      customRoomId: customRoomCode,
      includeMic,
      micDeviceId: micDevice || null,
      audioMode,
    });
  };

  const handleJoin = (e) => {
    e.preventDefault();
    if (!user) {
      showToast('Please sign in with Google to watch streams.', 'warning');
      signInWithGoogle().catch((e) => showToast(e.message, 'error'));
      return;
    }
    const clean = joinCode.trim().toUpperCase();
    if (!clean) {
      showToast('Please enter a valid room code.', 'warning');
      return;
    }
    onJoinStream(clean);
  };

  const resLabel = resolution === '4k' ? '4K UHD' : resolution === '1440p' ? '1440p 2K' : resolution === '1080p' ? '1080p FHD' : '720p HD';

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-16">
      {/* CARD 1: BRAND & AUTH */}
      <section className="glass-card rounded-3xl p-6 sm:p-8">
        {!user ? (
          <div className="text-center space-y-4">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-extrabold uppercase tracking-wider bg-amber-100/70 text-amber-900 border border-amber-200">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              120Hz Ultra-Smooth WebRTC Engine
            </div>
            <h2 className="text-3xl font-extrabold tracking-tight text-stone-900">
              Welcome to <span className="bg-gradient-to-r from-amber-600 to-amber-700 bg-clip-text text-transparent">NovaStream</span>
            </h2>
            <p className="text-sm text-stone-600 max-w-md mx-auto">
              Broadcast games, desktop windows, or full monitors in native 120 FPS / 60 FPS with near-zero latency (&lt; 15ms).
            </p>
            <div>
              <button
                onClick={() => signInWithGoogle().catch((e) => showToast(e.message, 'error'))}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full text-sm font-bold text-stone-800 bg-white/90 hover:bg-white border border-stone-200 shadow-md hover:shadow-lg transition-all active:scale-95"
                type="button"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                Sign in with Google
              </button>
            </div>
            <div className="flex flex-wrap justify-center gap-2 pt-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold text-stone-700 bg-white/60 border border-white/80">
                <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_6px_#10b981]" />
                ⚡ 120 FPS Buttery Smooth
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold text-stone-700 bg-white/60 border border-white/80">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                Native 4K &amp; 1080p UHD
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold text-stone-700 bg-white/60 border border-white/80">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                Zero Delay (&lt; 15ms)
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold text-stone-700 bg-white/60 border border-white/80">
                <Shield className="w-3.5 h-3.5 text-amber-600" />
                🔒 E2EE Encrypted Chat
              </span>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="relative">
                <img
                  src={user.photoURL || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(user.displayName || 'U')}`}
                  alt={user.displayName || 'User'}
                  className="w-12 h-12 rounded-full border-2 border-white shadow-md object-cover"
                />
                <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white shadow-[0_0_6px_#10b981]" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-stone-900 text-base">{user.displayName || 'Streamer'}</span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300">
                    Signed In
                  </span>
                </div>
                <span className="text-xs text-stone-500">{user.email}</span>
              </div>
            </div>
            <button
              onClick={() => logOut()}
              className="px-3.5 py-1.5 rounded-full text-xs font-bold text-stone-600 hover:text-stone-900 bg-white/60 hover:bg-white border border-stone-200 transition-colors"
              type="button"
            >
              Sign out
            </button>
          </div>
        )}
      </section>

      {/* CARD 2: BROADCAST FROM THIS DEVICE */}
      <section className="glass-card rounded-3xl p-6 sm:p-8 space-y-5">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 border border-white/80 flex items-center justify-center text-amber-700 shadow-sm shrink-0">
            <Video className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-extrabold text-stone-900">Broadcast From This Device</h2>
            <p className="text-xs text-stone-600 mt-0.5">
              Share any game, application window, or monitor at native 120 FPS / 60 FPS refresh rates with stereo game audio.
            </p>
          </div>
        </div>

        <div className="space-y-4 pt-1">
          {/* Resolution & Framerate */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-[11px] font-extrabold uppercase tracking-wider text-amber-900 mb-1">
                Resolution
              </label>
              <select
                value={resolution}
                onChange={(e) => setResolution(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 bg-white/70 focus:bg-white focus:border-amber-500 font-medium text-xs outline-none"
              >
                <option value="4k">4K Ultra HD (3840x2160)</option>
                <option value="1440p">1440p 2K (2560x1440)</option>
                <option value="1080p">1080p Full HD (1920x1080)</option>
                <option value="720p">720p HD (1280x720)</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-extrabold uppercase tracking-wider text-amber-900 mb-1">
                Frame Rate (Refresh Rate)
              </label>
              <select
                value={frameRate}
                onChange={(e) => setFrameRate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 bg-white/70 focus:bg-white focus:border-amber-500 font-medium text-xs outline-none"
              >
                <option value="120">⚡ 120 FPS (Buttery Smooth 120Hz Pro)</option>
                <option value="60">60 FPS (Ultra Smooth Standard)</option>
                <option value="30">30 FPS (Low Bandwidth)</option>
              </select>
            </div>
          </div>

          {/* Video Bitrate */}
          <div>
            <label className="block text-[11px] font-extrabold uppercase tracking-wider text-amber-900 mb-1">
              Video Bitrate
            </label>
            <select
              value={bitrate}
              onChange={(e) => setBitrate(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 bg-white/70 focus:bg-white focus:border-amber-500 font-medium text-xs outline-none"
            >
              <option value="50">50 Mbps (120 FPS / 4K Extreme Master)</option>
              <option value="40">40 Mbps (4K / 120 FPS Ultra Quality)</option>
              <option value="25">25 Mbps (120 FPS Gaming / 4K Recommended)</option>
              <option value="18">18 Mbps (1080p 120 FPS Recommended)</option>
              <option value="12">12 Mbps (1080p 60 FPS High)</option>
              <option value="10">10 Mbps (Recommended for 1080p 60 FPS)</option>
              <option value="8">8 Mbps (Standard High Speed)</option>
              <option value="5">5 Mbps (Standard Network)</option>
            </select>
            <span className="text-[10px] text-stone-500 block mt-1">
              Enforces WebRTC sender bitrate with maintain-framerate degradation.
            </span>
          </div>

          {/* Custom Room Code */}
          <div>
            <label className="block text-[11px] font-extrabold uppercase tracking-wider text-amber-900 mb-1">
              Custom Room Code (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. GAMING (leave blank for random code)"
              maxLength={12}
              value={customRoomCode}
              onChange={(e) => setCustomRoomCode(e.target.value.toUpperCase())}
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 bg-white/70 focus:bg-white focus:border-amber-500 font-mono tracking-widest text-xs outline-none uppercase"
            />
          </div>

          {/* Microphone Mix Toggle */}
          <div className="pt-1">
            <label className="inline-flex items-center gap-2 cursor-pointer select-none text-xs font-semibold text-stone-700">
              <input
                type="checkbox"
                checked={includeMic}
                onChange={(e) => setIncludeMic(e.target.checked)}
                className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500 accent-amber-600 cursor-pointer"
              />
              <span>Mix Microphone commentary into stream</span>
            </label>
          </div>

          {/* Mic Settings Panel */}
          {includeMic && (
            <div className="p-4 bg-amber-50/60 rounded-2xl border border-amber-200/80 space-y-3 animate-fadeIn">
              {micDevices.length > 0 && (
                <div>
                  <label className="block text-[11px] font-extrabold uppercase tracking-wider text-amber-900 mb-1">
                    Microphone Device
                  </label>
                  <select
                    value={micDevice}
                    onChange={(e) => setMicDevice(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-stone-200 bg-white text-xs outline-none"
                  >
                    <option value="">Default System Microphone</option>
                    {micDevices.map((d) => (
                      <option key={d.deviceId} value={d.deviceId}>
                        {d.label || `Microphone (${d.deviceId.slice(0, 5)})`}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-[11px] font-extrabold uppercase tracking-wider text-amber-900 mb-1">
                  Audio Profile Mode
                </label>
                <select
                  value={audioMode}
                  onChange={(e) => setAudioMode(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-stone-200 bg-white text-xs outline-none"
                >
                  <option value="gaming">🎮 Gaming &amp; Hi-Fi Music (Raw Stereo, No Filtering)</option>
                  <option value="voice">🎙️ Voice Commentary (Noise Suppression &amp; Echo Cancellation)</option>
                </select>
              </div>
            </div>
          )}

          {/* Start Stream Button */}
          <button
            onClick={handleStart}
            disabled={isStarting}
            className="w-full py-3.5 px-6 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-600 text-white font-extrabold text-sm shadow-lg shadow-amber-600/30 transition-all active:scale-[0.98] disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
            type="button"
          >
            {isStarting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-white" />
                Requesting Screen Access...
              </>
            ) : (
              <>
                <span className="w-2.5 h-2.5 rounded-full bg-white shadow-sm" />
                Start {resLabel} @ {frameRate} FPS Stream
              </>
            )}
          </button>

          <div className="text-center pt-1 text-[11px] text-stone-500">
            <span>Streaming to a friend on another network or ISP? </span>
            <button
              onClick={onOpenSettings}
              className="font-bold text-amber-700 hover:underline inline cursor-pointer"
              type="button"
            >
              Configure free TURN relay
            </button>
          </div>
        </div>
      </section>

      {/* CARD 3: WATCH A STREAM */}
      <section className="glass-card rounded-3xl p-6 sm:p-8 space-y-5">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 border border-white/80 flex items-center justify-center text-amber-700 shadow-sm shrink-0">
            <Tv className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-extrabold text-stone-900">Watch A Stream</h2>
            <p className="text-xs text-stone-600 mt-0.5">
              Enter your friend's 6-character room code to watch in 120 FPS ultra-low-latency with two-way voice chat.
            </p>
          </div>
        </div>

        <form onSubmit={handleJoin} className="space-y-4">
          <div>
            <label className="block text-[11px] font-extrabold uppercase tracking-wider text-amber-900 mb-1">
              Room Code
            </label>
            <input
              type="text"
              placeholder="e.g. AB12CD"
              maxLength={12}
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
              className="w-full px-4 py-3 rounded-xl border border-stone-200 bg-white/70 focus:bg-white focus:border-amber-500 font-mono tracking-widest text-base font-extrabold text-stone-800 outline-none uppercase text-center"
            />
          </div>

          <button
            type="submit"
            disabled={!joinCode.trim() || isJoining}
            className="w-full py-3.5 px-6 rounded-full bg-stone-900 hover:bg-stone-800 text-white font-extrabold text-sm shadow-md transition-all active:scale-[0.98] disabled:opacity-40 flex items-center justify-center gap-2 cursor-pointer"
          >
            {isJoining ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-white" />
                Connecting to Room...
              </>
            ) : (
              <>
                <span>Join Stream</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>
      </section>
    </div>
  );
}

