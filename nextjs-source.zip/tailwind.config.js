/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        bg: {
          primary: '#fdfbf0',
          secondary: '#fefce8',
        },
        accent: {
          primary: '#d97706',
          'primary-hover': '#b45309',
          honey: '#f59e0b',
          'gold-light': '#fef08a',
          emerald: '#059669',
          cyan: '#0284c7',
          rose: '#e11d48',
        },
      },
      transitionTimingFunction: {
        'fluid': 'cubic-bezier(0.16, 1, 0.3, 1)',
      },
      boxShadow: {
        'glass': '0 16px 36px -12px rgba(180, 83, 9, 0.12), 0 4px 10px -2px rgba(180, 83, 9, 0.04), inset 0 1px 1px 0 rgba(255, 255, 255, 0.95), inset 0 -1px 2px 0 rgba(217, 119, 6, 0.06)',
        'glass-hover': '0 25px 50px -10px rgba(180, 83, 9, 0.18), inset 0 1px 2px rgba(255, 255, 255, 1)',
        'glow': '0 0 25px rgba(245, 158, 11, 0.35)',
        'live': '0 0 20px rgba(225, 29, 72, 0.4)',
      },
    },
  },
  plugins: [],
};
