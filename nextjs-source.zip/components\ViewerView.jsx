'use client';
import React, { useEffect, useRef, useState } from 'react';
import {
  Mic,
  MicOff,
  Maximize2,
  RotateCw,
  Volume2,
  VolumeX,
  MessageSquare,
  BarChart3,
  Power,
  Zap,
  Pause,
  PictureInPicture2,
} from 'lucide-react';
import ChatPanel from './ChatPanel';
import { setViewerMicMuted, leaveStream } from '../lib/viewer';

export default function ViewerView({
  roomId,
  remoteStream,
  hostDetails,
  onLeaveStream,
  currentUser,
  stats,
  isPaused,
  showToast,
}) {
  const videoRef = useRef(null);
  const stageRef = useRef(null);
  const [isMicMuted, setIsMicMuted] = useState(true);
  const [isMutedAudio, setIsMutedAudio] = useState(false);
  const [showUnmuteBanner, setShowUnmuteBanner] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [activeTab, setActiveTab] = useState('chat');
  const [controlsVisible, setControlsVisible] = useState(true);

  // Bind incoming remote stream and setup requestVideoFrameCallback
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !remoteStream) return;

    if (video.srcObject !== remoteStream) {
      video.srcObject = remoteStream;
      video.preservesPitch = false;

      // 120Hz V-Sync frame alignment
      if ('requestVideoFrameCallback' in video) {
        const syncVsync = () => {
          if (videoRef.current) {
            videoRef.current.requestVideoFrameCallback(syncVsync);
          }
        };
        video.requestVideoFrameCallback(syncVsync);
      }
    }

    // Attempt unmuted play first; fallback to muted if browser autoplay blocks audio
    video.muted = false;
    video
      .play()
      .then(() => setShowUnmuteBanner(false))
      .catch(() => {
        video.muted = true;
        video.play().catch(() => {});
        setShowUnmuteBanner(true);
      });
  }, [remoteStream]);

  // Handle Fullscreen Mouse Move auto-hide
  useEffect(() => {
    let inactivityTimer = null;
    let rafId = null;

    const handleMouseMove = () => {
      if (!document.fullscreenElement) return;
      if (rafId) return;

      rafId = requestAnimationFrame(() => {
        rafId = null;
        if (!document.fullscreenElement) return;

        setControlsVisible(true);
        clearTimeout(inactivityTimer);
        inactivityTimer = setTimeout(() => {
          if (document.fullscreenElement) {
            setControlsVisible(false);
          }
        }, 2500);
      });
    };

    const stage = stageRef.current;
    if (stage) {
      stage.addEventListener('mousemove', handleMouseMove, { passive: true });
      stage.addEventListener('click', handleMouseMove, { passive: true });
    }

    return () => {
      clearTimeout(inactivityTimer);
      if (stage) {
        stage.removeEventListener('mousemove', handleMouseMove);
        stage.removeEventListener('click', handleMouseMove);
      }
    };
  }, []);

  const handleUnmuteClick = () => {
    if (videoRef.current) {
      videoRef.current.muted = false;
      videoRef.current.volume = 1.0;
      videoRef.current.play().catch(() => {});
    }
    setShowUnmuteBanner(false);
    setIsMutedAudio(false);
    showToast('Audio unmuted 🔊', 'success');
  };

  const toggleMic = async () => {
    const next = !isMicMuted;
    setIsMicMuted(next);
    await setViewerMicMuted(next);
    showToast(next ? 'Voice chat muted 🔇' : 'Voice chat connected 🎙️', 'info');
  };

  const rotateVideo = () => {
    const nextRot = (rotation + 90) % 360;
    setRotation(nextRot);
    showToast(`Rotation: ${nextRot}° 🔄`, 'info');
  };

  const togglePip = async () => {
    const video = videoRef.current;
    if (!video) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else if (document.pictureInPictureEnabled) {
        await video.requestPictureInPicture();
      }
    } catch (_) {}
  };

  const toggleFullscreen = () => {
    const stage = stageRef.current;
    if (!stage) return;
    if (!document.fullscreenElement) {
      stage.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-6 max-w-7xl mx-auto pb-12">
      {/* LEFT: Video Stage & Controls */}
      <div className="space-y-4">
        <div
          ref={stageRef}
          id="viewer-stage"
          className={`video-stage-container rounded-3xl border border-white/80 shadow-2xl ${
            controlsVisible ? 'controls-visible' : 'hide-cursor'
          }`}
        >
          <video
            ref={videoRef}
            className="main-video-element"
            autoPlay
            playsInline
            style={{
              transform: `rotate(${rotation}deg) translate3d(0, 0, 0)`,
            }}
          />

          {/* Autoplay Unmute Overlay Banner */}
          {showUnmuteBanner && (
            <div
              onClick={handleUnmuteClick}
              className="absolute inset-0 bg-amber-50/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center cursor-pointer z-30 animate-fadeIn"
            >
              <div className="w-16 h-16 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-700 mb-3 animate-pulse">
                <VolumeX className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-extrabold text-amber-950 mb-1">Click to Enable Audio</h3>
              <p className="text-xs text-stone-600 mb-4 max-w-xs">
                Your browser paused audio playback. Click anywhere on the stream to unmute.
              </p>
              <button
                type="button"
                className="px-6 py-2.5 rounded-full bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xs shadow-lg transition-transform active:scale-95 cursor-pointer"
              >
                Unmute Stream 🔊
              </button>
            </div>
          )}

          {/* Privacy Pause Slate */}
          {isPaused && (
            <div className="absolute inset-0 bg-stone-900/85 backdrop-blur-md flex flex-col items-center justify-center text-center p-6 text-white z-20 animate-fadeIn">
              <div className="w-16 h-16 rounded-full bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 mb-3 animate-pulse">
                <Pause className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-extrabold mb-1">Host Paused Stream</h3>
              <p className="text-xs text-stone-400 max-w-xs">
                The streamer has momentarily activated their privacy slate. Video will resume automatically.
              </p>
            </div>
          )}

          {/* Overlay Live Badge */}
          <div className="absolute top-4 left-4 flex items-center gap-2 bg-emerald-600/90 text-white text-[11px] font-extrabold uppercase tracking-wider px-3 py-1.5 rounded-full shadow-lg border border-white/30 z-10">
            <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
            LIVE P2P
          </div>

          {/* Overlay 120 FPS Telemetry Badge */}
          <div className="absolute top-4 right-4 bg-white/80 backdrop-blur-md text-amber-900 font-mono text-xs font-extrabold px-3 py-1.5 rounded-full shadow-md border border-white z-10 flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-amber-600" />
            <span>{stats?.resolution || '1080p'}</span>
            <span>•</span>
            <span className="text-emerald-700">{stats?.fps || 120} FPS</span>
          </div>

          {/* Floating Video Toolbar */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-white/80 backdrop-blur-xl border border-white/80 shadow-2xl rounded-full px-4 py-2 flex items-center gap-3 z-10 video-toolbar-overlay">
            {/* Viewer Mic (Two-Way Voice Chat) */}
            <button
              onClick={toggleMic}
              className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                !isMicMuted
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-white/80 text-stone-700 hover:bg-white'
              }`}
              title={isMicMuted ? 'Speak to Streamer (Mic Muted)' : 'Mute Voice Chat'}
              type="button"
            >
              {isMicMuted ? <MicOff className="w-4 h-4 text-stone-500" /> : <Mic className="w-4 h-4 text-emerald-700" />}
            </button>

            {/* Screen Rotation */}
            <button
              onClick={rotateVideo}
              className="w-10 h-10 rounded-full bg-white/80 hover:bg-white text-stone-800 flex items-center justify-center transition-all"
              title="Rotate Stream (Landscape / Portrait)"
              type="button"
            >
              <RotateCw className="w-4 h-4" />
            </button>

            {/* Picture-in-Picture */}
            <button
              onClick={togglePip}
              className="w-10 h-10 rounded-full bg-white/80 hover:bg-white text-stone-800 flex items-center justify-center transition-all"
              title="Picture-in-Picture"
              type="button"
            >
              <PictureInPicture2 className="w-4 h-4" />
            </button>

            {/* Fullscreen */}
            <button
              onClick={toggleFullscreen}
              className="w-10 h-10 rounded-full bg-white/80 hover:bg-white text-stone-800 flex items-center justify-center transition-all"
              title="Fullscreen Mode"
              type="button"
            >
              <Maximize2 className="w-4 h-4" />
            </button>

            <div className="w-[1px] h-6 bg-stone-300 my-auto" />

            <button
              onClick={onLeaveStream}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-stone-800 hover:bg-stone-900 text-white text-xs font-bold transition-all shadow-md active:scale-95"
              type="button"
            >
              <Power className="w-3.5 h-3.5" />
              Leave
            </button>
          </div>
        </div>

        {/* Host Details Bar */}
        <div className="glass-panel rounded-2xl p-4 flex items-center justify-between gap-3 border border-white/80">
          <div className="flex items-center gap-3">
            <img
              src={hostDetails?.photoURL || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(hostDetails?.displayName || 'H')}`}
              alt={hostDetails?.displayName || 'Host'}
              className="w-10 h-10 rounded-full border-2 border-amber-500 object-cover"
            />
            <div>
              <span className="font-extrabold text-stone-900 text-sm block">
                {hostDetails?.displayName ? `${hostDetails.displayName}'s Stream` : 'Live Stream'}
              </span>
              <span className="text-[11px] text-stone-500 font-mono">Room: {roomId}</span>
            </div>
          </div>

          <button
            onClick={onLeaveStream}
            className="px-4 py-2 rounded-full border border-stone-200 text-xs font-bold text-stone-700 hover:bg-white transition-all active:scale-95"
            type="button"
          >
            Leave Stream
          </button>
        </div>
      </div>

      {/* RIGHT: Tabs (Chat vs Telemetry HUD) */}
      <div className="space-y-4">
        {/* Tab Selector */}
        <div className="glass-panel p-1 rounded-full flex border border-white/80">
          <button
            onClick={() => setActiveTab('chat')}
            className={`flex-1 py-2 px-3 rounded-full text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'chat'
                ? 'bg-white text-amber-900 shadow-sm'
                : 'text-stone-600 hover:text-stone-900'
            }`}
            type="button"
          >
            <MessageSquare className="w-3.5 h-3.5 text-amber-600" />
            Live Chat
          </button>
          <button
            onClick={() => setActiveTab('info')}
            className={`flex-1 py-2 px-3 rounded-full text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'info'
                ? 'bg-white text-amber-900 shadow-sm'
                : 'text-stone-600 hover:text-stone-900'
            }`}
            type="button"
          >
            <BarChart3 className="w-3.5 h-3.5 text-amber-600" />
            Stream Quality
          </button>
        </div>

        {activeTab === 'chat' ? (
          <ChatPanel roomId={roomId} currentUser={currentUser} isHost={false} />
        ) : (
          <div className="glass-panel rounded-2xl p-4 space-y-3 animate-fadeIn">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-amber-900 block">
              Live Stream Telemetry
            </span>

            <div className="grid grid-cols-2 gap-2.5">
              <div className="bg-white/70 p-3 rounded-xl border border-white">
                <span className="text-[10px] text-stone-500 uppercase font-bold block">Rendered FPS</span>
                <span className="font-mono text-base font-extrabold text-emerald-700">
                  {stats?.fps || 120} FPS
                </span>
              </div>

              <div className="bg-white/70 p-3 rounded-xl border border-white">
                <span className="text-[10px] text-stone-500 uppercase font-bold block">Bitrate</span>
                <span className="font-mono text-base font-extrabold text-amber-800">
                  {stats?.bitrateMbps || '0.0'} Mbps
                </span>
              </div>

              <div className="bg-white/70 p-3 rounded-xl border border-white">
                <span className="text-[10px] text-stone-500 uppercase font-bold block">Resolution</span>
                <span className="font-mono text-sm font-extrabold text-stone-800">
                  {stats?.resolution || '1080p'}
                </span>
              </div>

              <div className="bg-white/70 p-3 rounded-xl border border-white">
                <span className="text-[10px] text-stone-500 uppercase font-bold block">Latency / Ping</span>
                <span className="font-mono text-sm font-extrabold text-stone-800">
                  {stats?.rtt || '< 15 ms'}
                </span>
              </div>
            </div>

            <div className="bg-white/70 p-3 rounded-xl border border-white flex items-center justify-between">
              <span className="text-[10px] text-stone-500 uppercase font-bold">Connection Route</span>
              <span className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                {stats?.route || 'Direct P2P'}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

