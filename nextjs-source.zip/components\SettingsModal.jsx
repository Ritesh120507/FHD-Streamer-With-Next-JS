'use client';
import React, { useState, useEffect } from 'react';
import { X, Network, ExternalLink, ShieldCheck, CheckCircle2, AlertTriangle, Loader2 } from 'lucide-react';
import { getTurnSettings, saveTurnSettings, clearTurnSettings, testTurnConnection } from '../lib/webrtc';

export default function SettingsModal({ isOpen, onClose, showToast }) {
  const [activeTab, setActiveTab] = useState('metered');
  const [settings, setSettings] = useState({
    provider: 'metered',
    meteredAppName: '',
    meteredApiKey: '',
    turnServerUrl: '',
    turnUsername: '',
    turnCredential: '',
  });

  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    if (isOpen) {
      const current = getTurnSettings();
      setSettings(current);
      setActiveTab(current.provider || 'metered');
      setTestResult(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSave = () => {
    const updated = { ...settings, provider: activeTab };
    saveTurnSettings(updated);
    showToast('Network & TURN settings saved!', 'success');
    onClose();
  };

  const handleClear = () => {
    clearTurnSettings();
    setSettings({
      provider: 'metered',
      meteredAppName: '',
      meteredApiKey: '',
      turnServerUrl: '',
      turnUsername: '',
      turnCredential: '',
    });
    setTestResult(null);
    showToast('TURN configuration reset to STUN only', 'info');
  };

  const handleTest = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await testTurnConnection({ ...settings, provider: activeTab });
      setTestResult(res);
    } catch (err) {
      setTestResult({ success: false, message: err.message || 'Probe failed.' });
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-md animate-fadeIn">
      <div className="glass-panel w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl border border-white/80 bg-white/90 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-amber-900/10 flex items-center justify-between bg-white/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-white shadow-md">
              <Network className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-stone-900">Network &amp; TURN Relay Settings</h3>
              <p className="text-xs text-stone-500">Enable cross-network and mobile 4G/5G streaming</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-stone-400 hover:text-stone-800 transition-colors p-1 rounded-lg"
            type="button"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-stone-700">
          <div className="bg-amber-50/80 border border-amber-200/80 rounded-2xl p-4 flex gap-3 text-amber-900">
            <ShieldCheck className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="text-xs leading-relaxed">
              <strong>Why configure a TURN Relay?</strong> When you stream to friends on different Wi-Fi networks or mobile 4G/5G, direct P2P connections are often blocked by ISP firewalls (CGNAT). A free TURN relay guarantees a 100% connection success rate anywhere in the world.
            </div>
          </div>

          {/* Tab Selector */}
          <div className="flex bg-amber-500/10 p-1 rounded-full border border-amber-500/20 gap-1">
            <button
              onClick={() => setActiveTab('metered')}
              className={`flex-1 py-1.5 px-3 rounded-full font-bold text-xs transition-all ${
                activeTab === 'metered' ? 'bg-white text-amber-700 shadow-sm' : 'text-stone-600 hover:text-stone-900'
              }`}
              type="button"
            >
              Metered.ca (Free 50 GB/Mo)
            </button>
            <button
              onClick={() => setActiveTab('custom')}
              className={`flex-1 py-1.5 px-3 rounded-full font-bold text-xs transition-all ${
                activeTab === 'custom' ? 'bg-white text-amber-700 shadow-sm' : 'text-stone-600 hover:text-stone-900'
              }`}
              type="button"
            >
              Custom TURN Server
            </button>
          </div>

          {/* Metered Tab */}
          {activeTab === 'metered' && (
            <div className="space-y-4">
              <div className="bg-amber-50/50 p-3 rounded-xl border border-amber-100 flex items-center justify-between">
                <span>Free 50 GB TURN Bandwidth every month:</span>
                <a
                  href="https://www.metered.ca/tools/openrelay/"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 font-bold text-amber-700 hover:underline"
                >
                  Get API Key <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              <div>
                <label className="block text-[11px] font-extrabold uppercase tracking-wider text-amber-900 mb-1.5">
                  Metered App Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. your-app-name"
                  value={settings.meteredAppName}
                  onChange={(e) => setSettings({ ...settings, meteredAppName: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 bg-white/70 focus:bg-white focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-none text-xs"
                />
              </div>

              <div>
                <label className="block text-[11px] font-extrabold uppercase tracking-wider text-amber-900 mb-1.5">
                  Metered API Key
                </label>
                <input
                  type="password"
                  placeholder="e.g. 1a2b3c4d5e6f..."
                  value={settings.meteredApiKey}
                  onChange={(e) => setSettings({ ...settings, meteredApiKey: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 bg-white/70 focus:bg-white focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-none text-xs"
                />
              </div>
            </div>
          )}

          {/* Custom Tab */}
          {activeTab === 'custom' && (
            <div className="space-y-3">
              <div>
                <label className="block text-[11px] font-extrabold uppercase tracking-wider text-amber-900 mb-1">
                  TURN Server URL(s)
                </label>
                <input
                  type="text"
                  placeholder="turn:your-server.com:3478, turns:your-server.com:443"
                  value={settings.turnServerUrl}
                  onChange={(e) => setSettings({ ...settings, turnServerUrl: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl border border-stone-200 bg-white/70 focus:bg-white focus:border-amber-500 outline-none text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-extrabold uppercase tracking-wider text-amber-900 mb-1">
                    Username
                  </label>
                  <input
                    type="text"
                    placeholder="Username"
                    value={settings.turnUsername}
                    onChange={(e) => setSettings({ ...settings, turnUsername: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl border border-stone-200 bg-white/70 focus:bg-white focus:border-amber-500 outline-none text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-extrabold uppercase tracking-wider text-amber-900 mb-1">
                    Credential / Password
                  </label>
                  <input
                    type="password"
                    placeholder="Password"
                    value={settings.turnCredential}
                    onChange={(e) => setSettings({ ...settings, turnCredential: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl border border-stone-200 bg-white/70 focus:bg-white focus:border-amber-500 outline-none text-xs"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Diagnostic Test Box */}
          <div className="pt-2">
            <button
              onClick={handleTest}
              disabled={testing}
              className="w-full py-2.5 px-4 rounded-xl border border-amber-300 text-amber-800 bg-amber-100/50 hover:bg-amber-100 font-bold transition-all flex items-center justify-center gap-2"
              type="button"
            >
              {testing ? <Loader2 className="w-4 h-4 animate-spin text-amber-700" /> : <ShieldCheck className="w-4 h-4" />}
              {testing ? 'Testing TURN Relay...' : 'Test Relay Connection'}
            </button>

            {testResult && (
              <div
                className={`mt-3 p-3 rounded-xl border flex items-start gap-2.5 text-xs ${
                  testResult.success
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : 'bg-rose-50 border-rose-200 text-rose-800'
                }`}
              >
                {testResult.success ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                )}
                <span>{testResult.message}</span>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-amber-900/10 flex items-center justify-between bg-white/50">
          <button
            onClick={handleClear}
            className="text-stone-500 hover:text-stone-800 text-xs font-bold transition-colors"
            type="button"
          >
            Reset to Default
          </button>
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-full border border-stone-200 text-stone-700 hover:bg-stone-50 font-bold text-xs transition-colors"
              type="button"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="px-5 py-2 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-600 text-white font-bold text-xs shadow-md transition-all active:scale-95"
              type="button"
            >
              Save &amp; Activate
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

