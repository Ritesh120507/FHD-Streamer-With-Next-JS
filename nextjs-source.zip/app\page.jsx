'use client';
import React, { useEffect, useState, useCallback, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import LiquidBackground from '../components/LiquidBackground';
import Navbar from '../components/Navbar';
import LobbyView from '../components/LobbyView';
import StudioView from '../components/StudioView';
import ViewerView from '../components/ViewerView';
import SettingsModal from '../components/SettingsModal';
import { subscribeToAuth } from '../lib/firebase';
import { startStream, stopStream } from '../lib/streamer';
import { joinStream, leaveStream } from '../lib/viewer';

function MainAppContent() {
  const searchParams = useSearchParams();
  const [currentUser, setCurrentUser] = useState(null);
  const [view, setView] = useState('lobby'); // 'lobby', 'studio', 'viewer'
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [toasts, setToasts] = useState([]);

  // Stream state
  const [activeRoomId, setActiveRoomId] = useState('');
  const [activeStream, setActiveStream] = useState(null);
  const [remoteStream, setRemoteStream] = useState(null);
  const [hostDetails, setHostDetails] = useState(null);
  const [stats, setStats] = useState(null);
  const [viewers, setViewers] = useState([]);
  const [isPaused, setIsPaused] = useState(false);
  const [isStarting, setIsStarting] = useState(false);
  const [isJoining, setIsJoining] = useState(false);

  // Toast Notification System
  const showToast = useCallback((message, type = 'info', duration = 3500) => {
    const id = Date.now() + Math.random().toString(36).substring(2, 6);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, duration);
  }, []);

  // Subscribe to Firebase Auth
  useEffect(() => {
    const unsubscribe = subscribeToAuth((user) => {
      setCurrentUser(user);
    });
    return () => unsubscribe();
  }, []);

  // Handle URL Query auto-join (?room=...)
  useEffect(() => {
    const roomParam = searchParams.get('room');
    if (roomParam && view === 'lobby' && currentUser) {
      handleJoinStream(roomParam);
    }
  }, [searchParams, currentUser, view]);

  // Streamer: Start Stream
  const handleStartStream = async (options) => {
    setIsStarting(true);
    try {
      await startStream(options, {
        onStreamReady: ({ roomId, stream, settings }) => {
          setActiveRoomId(roomId);
          setActiveStream(stream);
          setView('studio');
          showToast(`Stream Live! Room: ${roomId} • ${options.resolution.toUpperCase()} @ ${options.frameRate} FPS (120Hz locked)`, 'success');
        },
        onViewerConnected: (viewer) => {
          showToast(`${viewer.displayName || 'Friend'} joined the stream!`, 'success');
        },
        onViewersChanged: (count, list) => {
          setViewers(list);
        },
        onViewerVoiceReceived: () => {
          showToast('Viewer voice chat connected 🎙️', 'info');
        },
        onViewerDisconnected: () => {
          showToast('A viewer disconnected.', 'warning');
        },
        onStatsUpdate: (s) => {
          setStats(s);
        },
        onError: (err) => {
          showToast(err.message, 'error', 6000);
          if (err.isNatFailure) setSettingsOpen(true);
        },
      });
    } catch (err) {
      showToast(err.message || 'Failed to start stream', 'error');
    } finally {
      setIsStarting(false);
    }
  };

  // Streamer: Stop Stream
  const handleStopStream = async () => {
    await stopStream();
    setActiveStream(null);
    setActiveRoomId('');
    setViewers([]);
    setStats(null);
    setView('lobby');
    showToast('Stream ended.', 'info');
  };

  // Viewer: Join Stream
  const handleJoinStream = async (roomId) => {
    setIsJoining(true);
    try {
      await joinStream(roomId, {
        onHostDetails: (host, settings) => {
          setHostDetails(host);
        },
        onStreamTrackReceived: (stream) => {
          setRemoteStream(stream);
          setActiveRoomId(roomId);
          setView('viewer');
          showToast('Connected! Buttery Smooth 120Hz/60FPS Stream Active ⚡', 'success');
        },
        onStatsUpdate: (s) => {
          setStats(s);
        },
        onStreamPauseChanged: (paused) => {
          setIsPaused(paused);
        },
        onStreamEnded: () => {
          showToast('The host ended this stream.', 'warning');
          handleLeaveStream();
        },
        onError: (err) => {
          showToast(err.message, 'error', 7000);
          if (err.isNatFailure) setSettingsOpen(true);
        },
      });
    } catch (err) {
      showToast(err.message || 'Failed to join stream', 'error');
    } finally {
      setIsJoining(false);
    }
  };

  // Viewer: Leave Stream
  const handleLeaveStream = () => {
    leaveStream();
    setRemoteStream(null);
    setActiveRoomId('');
    setHostDetails(null);
    setStats(null);
    setIsPaused(false);
    // Remove query param without page reload
    window.history.replaceState({}, document.title, window.location.pathname);
    setView('lobby');
  };

  return (
    <div className="min-h-screen relative overflow-hidden flex flex-col p-4 sm:p-6 lg:p-8">
      {/* 120Hz GPU Composited Liquid Amber Orbs */}
      <LiquidBackground />

      <div className="w-full max-w-7xl mx-auto flex-1 flex flex-col">
        {/* Navbar */}
        <Navbar
          user={currentUser}
          onOpenSettings={() => setSettingsOpen(true)}
          showToast={showToast}
        />

        {/* View Router */}
        <main className="flex-1">
          {view === 'lobby' && (
            <LobbyView
              user={currentUser}
              onStartStream={handleStartStream}
              onJoinStream={handleJoinStream}
              onOpenSettings={() => setSettingsOpen(true)}
              showToast={showToast}
              isStarting={isStarting}
              isJoining={isJoining}
              initialRoomCode={searchParams.get('room') || ''}
            />
          )}

          {view === 'studio' && (
            <StudioView
              roomId={activeRoomId}
              stream={activeStream}
              onStopStream={handleStopStream}
              currentUser={currentUser}
              stats={stats}
              viewers={viewers}
              showToast={showToast}
            />
          )}

          {view === 'viewer' && (
            <ViewerView
              roomId={activeRoomId}
              remoteStream={remoteStream}
              hostDetails={hostDetails}
              onLeaveStream={handleLeaveStream}
              currentUser={currentUser}
              stats={stats}
              isPaused={isPaused}
              showToast={showToast}
            />
          )}
        </main>
      </div>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        showToast={showToast}
      />

      {/* Toast Notification Container */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 pointer-events-none">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`px-4 py-3 rounded-2xl shadow-xl border text-xs font-bold flex items-center gap-2 pointer-events-auto animate-fadeIn ${
              t.type === 'success'
                ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
                : t.type === 'error'
                ? 'bg-rose-50 text-rose-900 border-rose-300'
                : t.type === 'warning'
                ? 'bg-amber-50 text-amber-900 border-amber-300'
                : 'bg-white/95 text-stone-900 border-white/80'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full shrink-0 ${
                t.type === 'success'
                  ? 'bg-emerald-500'
                  : t.type === 'error'
                  ? 'bg-rose-500'
                  : t.type === 'warning'
                  ? 'bg-amber-500'
                  : 'bg-amber-500'
              }`}
            />
            <span>{t.message}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Home() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center text-xs font-bold text-stone-400">Loading NovaStream...</div>}>
      <MainAppContent />
    </Suspense>
  );
}

