'use client';
import React, { useEffect, useState, useRef } from 'react';
import { Send, Lock, ShieldCheck } from 'lucide-react';
import { collection, addDoc, query, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { getFirebaseInstance } from '../lib/firebase';
import { deriveRoomKey, encryptMessageText, decryptMessageText } from '../lib/crypto';

export default function ChatPanel({ roomId, currentUser, isHost }) {
  const [messages, setMessages] = useState([]);
  const [inputVal, setInputVal] = useState('');
  const [sending, setSending] = useState(false);
  const [roomKey, setRoomKey] = useState(null);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (!roomId) return;
    let unsubscribe = null;

    async function initChatSession() {
      const key = await deriveRoomKey(roomId);
      setRoomKey(key);

      const { db } = await getFirebaseInstance();
      if (!db) return;

      const messagesRef = collection(db, 'rooms', roomId, 'messages');
      const q = query(messagesRef, orderBy('timestamp', 'asc'), limit(100));

      unsubscribe = onSnapshot(q, async (snapshot) => {
        const rawDocs = [];
        snapshot.forEach((doc) => {
          rawDocs.push({ id: doc.id, ...doc.data() });
        });

        const decrypted = await Promise.all(
          rawDocs.map(async (docData) => {
            let text = '';
            if (docData.ciphertext && docData.iv && key) {
              text = await decryptMessageText(docData.ciphertext, docData.iv, key);
            } else if (docData.text) {
              text = docData.text;
            }
            return { ...docData, text };
          })
        );

        setMessages(decrypted);

        // Smooth auto-scroll
        requestAnimationFrame(() => {
          if (messagesEndRef.current) {
            messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
          }
        });
      });
    }

    initChatSession();

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [roomId]);

  const handleSend = async (e) => {
    e.preventDefault();
    const text = inputVal.trim();
    if (!text || sending || !roomKey) return;

    setSending(true);
    setInputVal('');

    try {
      const { db } = await getFirebaseInstance();
      if (!db) throw new Error('Database not ready');

      const encrypted = await encryptMessageText(text, roomKey);
      const messagesRef = collection(db, 'rooms', roomId, 'messages');

      await addDoc(messagesRef, {
        ciphertext: encrypted.ciphertext,
        iv: encrypted.iv,
        senderUid: currentUser ? currentUser.uid : 'anon',
        senderName: currentUser ? (currentUser.displayName || 'Guest') : 'Guest',
        senderPhoto: currentUser ? currentUser.photoURL : '',
        isHost: Boolean(isHost),
        timestamp: Date.now(),
      });
    } catch (err) {
      console.warn('[NovaStream Chat] Failed to send message:', err);
    } finally {
      setSending(false);
    }
  };

  const formatTime = (ts) => {
    if (!ts) return '';
    const d = new Date(ts);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="glass-panel rounded-2xl flex flex-col h-[480px] overflow-hidden shadow-lg border border-white/70">
      {/* Header */}
      <div className="px-4 py-3 border-b border-amber-900/10 bg-white/60 flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-amber-900">
          <Lock className="w-3.5 h-3.5 text-amber-600" />
          <span>Live Chat</span>
        </div>
        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
          <ShieldCheck className="w-3 h-3" />
          E2EE 256-bit
        </span>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-white/20">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-stone-400 text-xs italic">
            No messages yet. Say hello!
          </div>
        ) : (
          messages.map((msg) => {
            const isMe = currentUser && msg.senderUid === currentUser.uid;
            return (
              <div
                key={msg.id}
                className={`flex gap-2.5 items-start ${isMe ? 'flex-row-reverse' : ''}`}
              >
                <img
                  src={msg.senderPhoto || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(msg.senderName || 'U')}`}
                  alt={msg.senderName}
                  className="w-7 h-7 rounded-full border border-amber-400 object-cover shrink-0 mt-0.5"
                />
                <div className={`max-w-[75%] flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                  <div className="flex items-center gap-1.5 text-[10px] text-stone-500 mb-0.5">
                    <span className="font-bold text-stone-700">{msg.senderName}</span>
                    {msg.isHost && (
                      <span className="px-1.5 py-0.2 bg-amber-600 text-white rounded font-extrabold text-[8px]">
                        HOST
                      </span>
                    )}
                    <span>{formatTime(msg.timestamp)}</span>
                  </div>
                  <div
                    className={`px-3 py-2 rounded-2xl text-xs break-words shadow-sm ${
                      isMe
                        ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-tr-none'
                        : 'bg-white/90 text-stone-900 border border-white rounded-tl-none'
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Form */}
      <form onSubmit={handleSend} className="p-2.5 bg-white/70 border-t border-amber-900/10 flex gap-2">
        <input
          type="text"
          placeholder="Send encrypted message..."
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          className="flex-1 px-3.5 py-2 rounded-full border border-stone-200 bg-white focus:outline-none focus:border-amber-500 text-xs"
        />
        <button
          type="submit"
          disabled={!inputVal.trim() || sending}
          className="w-8 h-8 rounded-full bg-amber-500 hover:bg-amber-600 text-white flex items-center justify-center disabled:opacity-40 transition-transform active:scale-90 shrink-0"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
}

