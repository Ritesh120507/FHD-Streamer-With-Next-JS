'use client';
import React, { useEffect, useRef, useState } from 'react';
import {
  Mic,
  MicOff,
  Pause,
  Play,
  Maximize2,
  Copy,
  Check,
  Share2,
  Users,
  MessageSquare,
  BarChart3,
  Power,
  Zap,
} from 'lucide-react';
import ChatPanel from './ChatPanel';
import { setStreamerMicMuted, setStreamPaused } from '../lib/streamer';

export default function StudioView({
  roomId,
  stream,
  onStopStream,
  currentUser,
  stats,
  viewers = [],
  showToast,
}) {
  const videoRef = useRef(null);
  const voiceAudioRef = useRef(null);
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [activeTab, setActiveTab] = useState('chat'); // 'chat' or 'info'

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
      videoRef.current.play().catch((e) => console.warn('Local play notice:', e));
    }
  }, [stream]);

  const toggleMic = () => {
    const next = !isMicMuted;
    setIsMicMuted(next);
    setStreamerMicMuted(next);
    showToast(next ? 'Microphone muted 🔇' : 'Microphone active 🎙️', 'info');
  };

  const togglePause = async () => {
    const next = !isPaused;
    setIsPaused(next);
    await setStreamPaused(next);
    showToast(next ? 'Stream paused (Privacy Slate active) ⏸️' : 'Stream resumed ▶️', 'info');
  };

  const copyRoomCode = () => {
    navigator.clipboard.writeText(roomId);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
    showToast(`Room Code "${roomId}" copied!`, 'success');
  };

  const copyShareLink = () => {
    const url = `${window.location.origin}?room=${roomId}`;
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
    showToast('Direct stream link copied to clipboard!', 'success');
  };

  const handleFullscreen = () => {
    const el = document.getElementById('studio-stage');
    if (el) {
      if (!document.fullscreenElement) {
        el.requestFullscreen().catch(() => {});
      } else {
        document.exitFullscreen().catch(() => {});
      }
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-6 max-w-7xl mx-auto pb-12">
      {/* LEFT: Video Stage & Controls */}
      <div className="space-y-4">
        <div id="studio-stage" className="video-stage-container rounded-3xl border border-white/80 shadow-2xl">
          <video
            ref={videoRef}
            className="main-video-element"
            autoPlay
            playsInline
            muted
          />

          {/* Privacy Pause Slate */}
          {isPaused && (
            <div className="absolute inset-0 bg-stone-900/85 backdrop-blur-md flex flex-col items-center justify-center text-center p-6 text-white z-20 animate-fadeIn">
              <div className="w-16 h-16 rounded-full bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 mb-3 animate-pulse">
                <Pause className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-extrabold mb-1">Stream Paused</h3>
              <p className="text-xs text-stone-400 max-w-xs">
                Privacy slate is active. Viewers cannot see your screen until you resume.
              </p>
            </div>
          )}

          {/* Overlay Live Badge */}
          <div className="absolute top-4 left-4 flex items-center gap-2 bg-rose-600/90 text-white text-[11px] font-extrabold uppercase tracking-wider px-3 py-1.5 rounded-full shadow-lg border border-white/30 z-10">
            <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
            LIVE ON AIR
          </div>

          {/* Overlay 120 FPS Telemetry Badge */}
          <div className="absolute top-4 right-4 bg-white/80 backdrop-blur-md text-amber-900 font-mono text-xs font-extrabold px-3 py-1.5 rounded-full shadow-md border border-white z-10 flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-amber-600" />
            <span>{stats?.resolution || '1080p'}</span>
            <span>•</span>
            <span className="text-emerald-700">{stats?.fps || 120} FPS</span>
          </div>

          {/* Floating Video Toolbar */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-white/80 backdrop-blur-xl border border-white/80 shadow-2xl rounded-full px-4 py-2 flex items-center gap-3 z-10 video-toolbar-overlay">
            <button
              onClick={toggleMic}
              className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                isMicMuted
                  ? 'bg-rose-100 text-rose-700 border border-rose-300'
                  : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
              }`}
              title={isMicMuted ? 'Unmute Microphone' : 'Mute Microphone'}
              type="button"
            >
              {isMicMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            <button
              onClick={togglePause}
              className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                isPaused
                  ? 'bg-rose-600 text-white shadow-lg shadow-rose-500/30'
                  : 'bg-white/80 text-stone-800 hover:bg-white'
              }`}
              title={isPaused ? 'Resume Screen Share' : 'Pause Screen Share (Privacy)'}
              type="button"
            >
              {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
            </button>

            <button
              onClick={handleFullscreen}
              className="w-10 h-10 rounded-full bg-white/80 hover:bg-white text-stone-800 flex items-center justify-center transition-all"
              title="Fullscreen"
              type="button"
            >
              <Maximize2 className="w-4 h-4" />
            </button>

            <div className="w-[1px] h-6 bg-stone-300 my-auto" />

            <button
              onClick={onStopStream}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-md active:scale-95"
              type="button"
            >
              <Power className="w-3.5 h-3.5" />
              End Stream
            </button>
          </div>
        </div>

        {/* Room Code & Sharing Bar */}
        <div className="glass-panel rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 border border-white/80">
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-amber-900 block">
              Stream Room Code
            </span>
            <span className="font-mono text-xl font-extrabold text-amber-900 tracking-widest">
              {roomId}
            </span>
          </div>

          <div className="flex gap-2">
            <button
              onClick={copyRoomCode}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full text-xs font-bold text-stone-700 bg-white/80 hover:bg-white border border-stone-200 shadow-sm transition-all active:scale-95"
              type="button"
            >
              {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-stone-500" />}
              {copiedCode ? 'Copied' : 'Copy Code'}
            </button>
            <button
              onClick={copyShareLink}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 shadow-md transition-all active:scale-95"
              type="button"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Share2 className="w-3.5 h-3.5" />}
              {copiedLink ? 'Link Copied' : 'Share Link'}
            </button>
          </div>
        </div>
      </div>

      {/* RIGHT: Tabs (Chat vs Telemetry HUD) */}
      <div className="space-y-4">
        {/* Tab Selector */}
        <div className="glass-panel p-1 rounded-full flex border border-white/80">
          <button
            onClick={() => setActiveTab('chat')}
            className={`flex-1 py-2 px-3 rounded-full text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'chat'
                ? 'bg-white text-amber-900 shadow-sm'
                : 'text-stone-600 hover:text-stone-900'
            }`}
            type="button"
          >
            <MessageSquare className="w-3.5 h-3.5 text-amber-600" />
            Live Chat
          </button>
          <button
            onClick={() => setActiveTab('info')}
            className={`flex-1 py-2 px-3 rounded-full text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'info'
                ? 'bg-white text-amber-900 shadow-sm'
                : 'text-stone-600 hover:text-stone-900'
            }`}
            type="button"
          >
            <BarChart3 className="w-3.5 h-3.5 text-amber-600" />
            Telemetry HUD
          </button>
        </div>

        {activeTab === 'chat' ? (
          <ChatPanel roomId={roomId} currentUser={currentUser} isHost={true} />
        ) : (
          <div className="space-y-4 animate-fadeIn">
            {/* Telemetry Cards */}
            <div className="glass-panel rounded-2xl p-4 space-y-3">
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-amber-900 block">
                Performance Telemetry
              </span>

              <div className="grid grid-cols-2 gap-2.5">
                <div className="bg-white/70 p-3 rounded-xl border border-white">
                  <span className="text-[10px] text-stone-500 uppercase font-bold block">Framerate</span>
                  <span className="font-mono text-base font-extrabold text-emerald-700">
                    {stats?.fps || 120} FPS
                  </span>
                </div>

                <div className="bg-white/70 p-3 rounded-xl border border-white">
                  <span className="text-[10px] text-stone-500 uppercase font-bold block">Bitrate</span>
                  <span className="font-mono text-base font-extrabold text-amber-800">
                    {stats?.bitrateMbps || '18.0'} Mbps
                  </span>
                </div>

                <div className="bg-white/70 p-3 rounded-xl border border-white">
                  <span className="text-[10px] text-stone-500 uppercase font-bold block">Resolution</span>
                  <span className="font-mono text-sm font-extrabold text-stone-800">
                    {stats?.resolution || '1080p'}
                  </span>
                </div>

                <div className="bg-white/70 p-3 rounded-xl border border-white">
                  <span className="text-[10px] text-stone-500 uppercase font-bold block">Latency / RTT</span>
                  <span className="font-mono text-sm font-extrabold text-stone-800">
                    {stats?.rtt || '< 15 ms'}
                  </span>
                </div>
              </div>

              <div className="bg-white/70 p-3 rounded-xl border border-white flex items-center justify-between">
                <span className="text-[10px] text-stone-500 uppercase font-bold">Connection Route</span>
                <span className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  {stats?.route || 'Direct P2P'}
                </span>
              </div>
            </div>

            {/* Audience Viewers Card */}
            <div className="glass-panel rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-amber-900">
                  Connected Audience ({viewers.length})
                </span>
                <Users className="w-4 h-4 text-amber-700" />
              </div>

              {viewers.length === 0 ? (
                <p className="text-xs text-stone-500 italic py-2">
                  Waiting for friends to join... Share your room link!
                </p>
              ) : (
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {viewers.map((v, idx) => (
                    <div key={idx} className="flex items-center gap-2.5 p-2 bg-white/60 rounded-xl border border-white/80">
                      <img
                        src={v.photoURL || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(v.displayName || 'V')}`}
                        alt={v.displayName}
                        className="w-7 h-7 rounded-full border border-amber-400"
                      />
                      <div className="flex flex-col min-w-0">
                        <span className="text-xs font-bold text-stone-800 truncate">{v.displayName || 'Friend'}</span>
                        <span className="text-[10px] text-stone-500 truncate">{v.email || 'Online'}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

